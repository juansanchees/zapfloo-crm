import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const dir = dirname(fileURLToPath(import.meta.url));
const owner = 'juansanchees';
const packages = ['zapfloo-crm', 'zapfloo-worker', 'zapfloo-scheduler', 'deskcommcrm', 'deskcomm-worker', 'deskcomm-scheduler'];
const accept = 'application/vnd.oci.image.index.v1+json,application/vnd.docker.distribution.manifest.list.v2+json,application/vnd.oci.image.manifest.v1+json,application/vnd.docker.distribution.manifest.v2+json';
const gh = (...args) => execFileSync('/Users/juansanches/bin/gh', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();

async function anonymous(name) {
  const url = `https://ghcr.io/v2/${owner}/${name}/manifests/stable`;
  const raw = await fetch(url, { headers: { Accept: accept } });
  // No PAT, cookies or Docker config: token exchange is anonymous too.
  const auth = await fetch(`https://ghcr.io/token?service=ghcr.io&scope=repository:${owner}/${name}:pull`);
  let manifestStatus = null;
  if (auth.ok) {
    const token = (await auth.json()).token;
    if (token) {
      const r = await fetch(url, { headers: { Accept: accept, Authorization: `Bearer ${token}` } });
      manifestStatus = r.status;
    }
  }
  return { name, rawStatus: raw.status, anonymousTokenStatus: auth.status, anonymousManifestStatus: manifestStatus };
}

const anon = [];
for (const name of packages.slice(0, 3)) anon.push(await anonymous(name));
writeFileSync(join(dir, 'anonymous-registry.json'), JSON.stringify({ measuredAt: new Date().toISOString(), results: anon }, null, 2));
console.log(JSON.stringify({ anonymous: anon }));
if (process.argv.includes('--anonymous-only')) process.exit(anon.every(r => r.anonymousManifestStatus === 200) ? 0 : 1);

// Existing CLI credential is used in memory only, never printed or written.
const credential = gh('auth', 'token');
const basic = Buffer.from(`${owner}:${credential}`).toString('base64');
const inventory = [];
for (const name of packages) {
  const metadata = JSON.parse(gh('api', `user/packages/container/${name}`));
  const pages = JSON.parse(gh('api', '--paginate', '--slurp', `user/packages/container/${name}/versions?per_page=100`));
  const versions = pages.flat().map(v => ({ id: v.id, digest: v.name, tags: v.metadata.container.tags, created_at: v.created_at }));
  const auth = await fetch(`https://ghcr.io/token?service=ghcr.io&scope=repository:${owner}/${name}:pull`, { headers: { Authorization: `Basic ${basic}` } });
  if (!auth.ok) throw new Error(`Registry token unavailable for ${name}: HTTP ${auth.status}`);
  const token = (await auth.json()).token;
  const all = new Map();
  async function manifest(digest) {
    if (all.has(digest)) return;
    const r = await fetch(`https://ghcr.io/v2/${owner}/${name}/manifests/${digest}`, { headers: { Accept: accept, Authorization: `Bearer ${token}` } });
    if (!r.ok) throw new Error(`Manifest unavailable for ${name} ${digest}: HTTP ${r.status}`);
    const m = await r.json();
    const children = (m.manifests || []).map(x => x.digest);
    const refs = [...children, ...(m.subject?.digest ? [m.subject.digest] : [])];
    all.set(digest, { mediaType: m.mediaType, refs, blobs: [...(m.layers || []), ...(m.config ? [m.config] : [])].map(x => ({ digest: x.digest, size: x.size })) });
    for (const child of refs) await manifest(child);
  }
  for (const v of versions) await manifest(v.digest);
  const protectedDigests = new Set();
  function protect(digest) {
    if (protectedDigests.has(digest)) return;
    protectedDigests.add(digest);
    for (const child of all.get(digest)?.refs || []) protect(child);
  }
  for (const v of versions.filter(v => v.tags.length)) protect(v.digest);
  const blobSizes = new Map([...all.values()].flatMap(m => m.blobs.map(b => [b.digest, b.size])));
  const result = { name, visibility: metadata.visibility, versions: versions.map(v => ({ ...v, reachableFromTag: protectedDigests.has(v.digest), references: all.get(v.digest).refs })), uniqueBlobBytes: [...blobSizes.values()].reduce((a, b) => a + b, 0), manifests: Object.fromEntries(all) };
  inventory.push(result);
  console.log(JSON.stringify({ name, visibility: result.visibility, versions: versions.length, untagged: versions.filter(v => !v.tags.length).length, unreachableFromTag: result.versions.filter(v => !v.reachableFromTag).map(v => ({ id: v.id, digest: v.digest })), uniqueBlobBytes: result.uniqueBlobBytes }));
}
writeFileSync(join(dir, 'registry-inventory.json'), JSON.stringify({ measuredAt: new Date().toISOString(), packages: inventory }, null, 2));
