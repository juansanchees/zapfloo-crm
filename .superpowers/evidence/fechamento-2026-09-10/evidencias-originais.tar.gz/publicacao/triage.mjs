import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
const repo = '/Users/juansanches/Documents/ChatGPT/CRM SAAS Deskcomm';
const dir = '/Users/juansanches/Desktop/zapfloo-publicacao-2026-09-10';
const findings = JSON.parse(readFileSync(`${dir}/gitleaks-redacted.json`, 'utf8'));
const git = (...args) => execFileSync('git', ['-C', repo, ...args], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
function scrub(line) {
  return line.replace(/(["'`])(?:\\.|(?!\1).)*?\1/g, m => `<literal:${m.length - 2}>`)
    .replace(/[A-Za-z0-9_+/=-]{24,}/g, '<valor-omitido>')
    .replace(/eyJ[\w.-]+/g, '<jwt-omitido>');
}
const results = [];
for (const f of findings) {
  // No historical .env body is opened here: it is handled only by the redacted scanner.
  const r = { commit: f.Commit, file: f.File, line: f.StartLine, rule: f.RuleID };
  r.upstreamAncestor = (() => { try { git('merge-base', '--is-ancestor', f.Commit, 'upstream/main'); return true; } catch { return false; } })();
  if (!f.File.startsWith('.env')) {
    let body;
    try { body = git('show', `${f.Commit}:${f.File}`); }
    catch { body = git('show', `${f.Commit}^:${f.File}`); r.sourceFromParent = true; }
    r.context = body.split('\n').slice(Math.max(0, f.StartLine - 3), f.StartLine + 2).map(scrub);
    if (f.RuleID === 'jwt') {
      r.jwtClaims = [...body.matchAll(/eyJ[\w-]+\.[\w-]+\.[\w-]+/g)].map(m => {
        const p = JSON.parse(Buffer.from(m[0].split('.')[1], 'base64url').toString());
        return { issuer: p.iss, role: p.role, projectRefPresent: Boolean(p.ref), issuedAt: p.iat, expiresAt: p.exp };
      });
      r.localEndpoint = /127\.0\.0\.1|localhost/.test(body);
    }
  }
  results.push(r);
  console.log(JSON.stringify(r));
}
writeFileSync(`${dir}/triagem-sem-valores.json`, JSON.stringify(results, null, 2));
