// Somente GETs, usando curl. Não lê gh, Docker config, .env ou credenciais.
// Rode novamente depois que o dono abrir os três pacotes.
import { execFileSync } from 'node:child_process';
const accept = 'application/vnd.oci.image.index.v1+json,application/vnd.docker.distribution.manifest.list.v2+json,application/vnd.oci.image.manifest.v1+json,application/vnd.docker.distribution.manifest.v2+json';
function get(url, token) {
  const args = ['-q', '--silent', '--show-error', '--connect-timeout', '10', '--max-time', '30', '--write-out', '\n%{http_code}', '--header', `Accept: ${accept}`];
  // Bearer anônimo somente em stdin: não entra na linha de comando nem no log.
  if (token) args.push('--config', '-');
  args.push(url);
  const out = execFileSync('curl', args, { encoding: 'utf8', input: token ? `header = "Authorization: Bearer ${token}"\n` : undefined, maxBuffer: 8 * 1024 * 1024 });
  const split = out.lastIndexOf('\n');
  return { status: Number(out.slice(split + 1)), body: out.slice(0, split) };
}
let passed = true;
for (const name of ['zapfloo-crm', 'zapfloo-worker', 'zapfloo-scheduler']) {
  const base = `https://ghcr.io/v2/juansanchees/${name}`;
  const raw = get(`${base}/manifests/stable`);
  const auth = get(`https://ghcr.io/token?service=ghcr.io&scope=repository:juansanchees/${name}:pull`);
  let manifestStatus = null;
  const children = [];
  if (auth.status === 200) {
    const token = JSON.parse(auth.body).token;
    if (token) {
      const manifest = get(`${base}/manifests/stable`, token);
      manifestStatus = manifest.status;
      if (manifest.status === 200) {
        for (const child of JSON.parse(manifest.body).manifests || []) {
          children.push({ digest: child.digest, status: get(`${base}/manifests/${child.digest}`, token).status });
        }
      }
    }
  }
  console.log(JSON.stringify({ name, semBearer: raw.status, tokenAnonimo: auth.status, manifestStable: manifestStatus, manifestsFilhos: children }));
  if (manifestStatus !== 200 || children.some(x => x.status !== 200)) passed = false;
}
process.exitCode = passed ? 0 : 1;
