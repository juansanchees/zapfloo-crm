import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
const dir = '/Users/juansanches/Desktop/zapfloo-publicacao-2026-09-10';
const repo = '/Users/juansanches/Documents/ChatGPT/CRM SAAS Deskcomm';
const git = (...a) => execFileSync('git', ['-C', repo, ...a], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
const base = JSON.parse(readFileSync(`${dir}/gitleaks-redacted.json`));
const all = JSON.parse(readFileSync(`${dir}/gitleaks-merges-redacted.json`));
const descriptions = {
  'lib/notifications/prefs.ts': 'Falso positivo: chave de preferencias, identificador de armazenamento; nao autentica servico.',
  'lib/followup/gatilho-caso.handler.ts': 'Falso positivo: identificador versionado de handler de evento; nao e API key.',
  'lib/followup/gatilho-etapa.handler.ts': 'Falso positivo: identificador versionado de handler de evento; nao e API key.',
  'supabase/migrations/MANIFEST.md': 'Falso positivo de credencial: identificador de conversa/thread citado na documentacao, nao chave de autenticacao. Identificador operacional historico, ja no upstream.',
  'tests/sonda-radar-isolamento-orgs.ts': 'Fixture: JWT local service_role, emissor supabase-demo, endpoint loopback, sem ref de projeto Cloud. Nao reutilizar em producao.',
  'lib/sentry/scrub.test.ts': 'Fixture: token sintetico para testar sanitizacao de logs.',
  'app/actions/auth/signInWithPassword.test.ts': 'Fixture: senha sintetica de teste com autenticacao mockada.',
  'evidence/canais/baseline/e2e.txt': 'Falso positivo: UUID de registro de credencial de fixture, nao a chave. Emissor seed-e2e-followup-agent.ts gera placeholder cifrado e imprime credentialId.',
  'evidence/canais/baseline/e2e-paralelo.txt': 'Falso positivo: UUID de registro de credencial de fixture, nao a chave. Emissor seed-e2e-followup-agent.ts gera placeholder cifrado e imprime credentialId.',
  'tests/invariants/webhooks-secret-encryption.test.ts': 'Fixture: chave sintetica usada no GUC do banco de teste para exercitar cifra.',
  'tests/invariants/webhooks-inbound.test.ts': 'Fixture: chave sintetica usada no GUC do banco de teste para exercitar cifra.',
  '.env.waha': 'Hash de autenticacao WAHA de 128 hex (compativel com SHA-512), nao chave plaintext; herdado do upstream publico. Recomendacao: rotacionar a chave original onde tenha sido usada; nao rotacionar automaticamente nem purgar sem aprovacao.'
};
function line(f) {
  if (f.File.startsWith('.env')) return null;
  let body;
  try { body = git('show', `${f.Commit}:${f.File}`); }
  catch { body = git('show', `${f.Commit}^:${f.File}`); }
  return body.split('\n')[f.StartLine - 1];
}
const known = new Map();
for (const f of base) {
  if (!known.has(f.File)) known.set(f.File, new Set());
  known.get(f.File).add(line(f));
}
const rows = all.map((f, i) => {
  let upstream;
  try { git('merge-base', '--is-ancestor', f.Commit, 'upstream/main'); upstream = true; } catch { upstream = false; }
  const currentLine = line(f);
  const matchesReviewedLine = known.get(f.File)?.has(currentLine) ?? false;
  const identifier = s => s?.match(/API real: `([^`]+)`/)?.[1];
  const matchesReviewedIdentifier = f.File === 'supabase/migrations/MANIFEST.md' && Boolean(identifier(currentLine)) && [...known.get(f.File)].some(s => identifier(s) === identifier(currentLine));
  return { occurrence: i + 1, commit: f.Commit, file: f.File, line: f.StartLine, rule: f.RuleID, upstream, matchesReviewedLine, matchesReviewedIdentifier, classification: descriptions[f.File] || 'NAO CLASSIFICADO', fingerprint: f.Fingerprint };
});
writeFileSync(`${dir}/achados-sem-valores.json`, JSON.stringify(rows, null, 2));
const header = '# Achados do historico completo — sem valores\n\n163 ocorrencias brutas incluindo repeticoes em merges. Cada linha abaixo corresponde a uma ocorrencia do detector, nao a uma credencial distinta. Classificacao por inspecao contextual, nao por supressao de regras. A coluna equivalencia compara a linha do merge com uma linha revisada na primeira rodada, sem publicar seu conteudo.\n\n| # | Commit | Arquivo:linha | Regra | Ancestral upstream | Equivale a linha revisada | O que e / acao |\n|---|---|---|---|---|---|---|\n';
writeFileSync(`${dir}/ACHADOS.md`, header + rows.map(r => `| ${r.occurrence} | \`${r.commit}\` | \`${r.file}:${r.line}\` | ${r.rule} | ${r.upstream ? 'sim' : 'nao'} | ${r.matchesReviewedLine ? 'sim' : r.matchesReviewedIdentifier ? 'mesmo identificador; prosa diferente' : 'REVISAR'} | ${r.classification} |`).join('\n') + '\n');
console.log(JSON.stringify({ occurrences: rows.length, uniqueFingerprints: new Set(rows.map(r => r.fingerprint)).size, allUpstream: rows.every(r => r.upstream), unmatched: rows.filter(r => !r.matchesReviewedLine && !r.matchesReviewedIdentifier).map(({commit,file,line})=>({commit,file,line})), unclassified: rows.filter(r=>r.classification==='NAO CLASSIFICADO').length }));
