import { test, expect } from '@playwright/test';
import { createClient } from '@supabase/supabase-js';
import { writeFileSync } from 'node:fs';

test('IA sem credencial falha no diálogo, preserva texto e não cria fluxo', async ({ page }) => {
  expect(process.env.NEXT_PUBLIC_SUPABASE_URL).toBe('http://127.0.0.1:55321');
  expect(process.env.RESEND_API_KEY).toBeUndefined();
  const db = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } });
  const { data: org } = await db.from('organizations').select('id').eq('slug', 'empresa-p0-de-teste').single();
  const { count: before } = await db.from('followup_flow_pointers').select('id', { count: 'exact', head: true }).eq('organization_id', org!.id);
  await page.goto('/login');
  await page.locator('#email').fill(process.env.OWNER_EMAIL!);
  await page.locator('#password').fill(process.env.OWNER_PASSWORD!);
  await page.getByRole('button', { name: /^Entrar$/i }).click();
  await page.waitForURL('**/onboarding/connect-whatsapp');
  await page.getByRole('button', { name: 'Explorar o CRM', exact: true }).last().click();
  await page.waitForURL('**/app/inbox');
  await page.locator('a[href="/app/ai/followups"]').first().click();
  await page.getByRole('button', { name: 'Novo fluxo', exact: true }).click();
  const dialog = page.getByRole('dialog');
  const text = 'Quando um cliente novo entrar em contato, encaminhe para atendimento humano sem enviar mensagens automáticas.';
  await dialog.locator('#flow-name').fill('Fluxo P0 de teste');
  await dialog.locator('#flow-description').fill(text);
  await dialog.getByRole('button', { name: 'Gerar rascunho', exact: true }).click();
  await expect(dialog.getByTestId('new-flow-error')).toBeVisible({ timeout: 30_000 });
  await expect(dialog.getByRole('link', { name: 'Revisar chaves de IA' })).toBeVisible();
  await expect(dialog.locator('#flow-description')).toHaveValue(text);
  await expect(dialog.locator('#flow-name')).toHaveValue('Fluxo P0 de teste');
  await expect(dialog.getByRole('button', { name: 'Gerar rascunho', exact: true })).toBeEnabled();
  const metrics = [];
  for (const width of [1440, 768, 390]) {
    await page.setViewportSize({ width, height: 1000 });
    const measure = await dialog.evaluate(el => {
      const r = el.getBoundingClientRect();
      return { viewport: innerWidth, left: r.left, right: r.right, clientWidth: el.clientWidth, scrollWidth: el.scrollWidth, fontSize: getComputedStyle(el).fontSize };
    });
    metrics.push(measure);
    await page.screenshot({ path: `.superpowers/evidence/jornada-p0-2026-09-10/fluxo-sem-chave-${width}.png`, fullPage: true });
    expect(measure.left).toBeGreaterThanOrEqual(0);
    expect(measure.right).toBeLessThanOrEqual(width);
    expect(measure.scrollWidth).toBeLessThanOrEqual(measure.clientWidth + 1);
  }
  const { count: after } = await db.from('followup_flow_pointers').select('id', { count: 'exact', head: true }).eq('organization_id', org!.id);
  expect(after).toBe(before);
  writeFileSync('.superpowers/evidence/jornada-p0-2026-09-10/fluxo-sem-chave.json', JSON.stringify({ before, after, metrics }, null, 2));
});
