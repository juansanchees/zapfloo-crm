import { test, expect } from '@playwright/test';
import { createClient } from '@supabase/supabase-js';
import { writeFileSync } from 'node:fs';

test('bootstrap fresco → conexão sem IA → falha visível → conversas, em três larguras', async ({ page }) => {
  expect(process.env.NEXT_PUBLIC_SUPABASE_URL).toBe('http://127.0.0.1:55321');
  for (const name of ['RESEND_API_KEY', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'GOOGLE_GENERATIVE_AI_API_KEY', 'AI_GATEWAY_API_KEY', 'META_APP_SECRET', 'META_WEBHOOK_VERIFY_TOKEN']) {
    expect(process.env[name], `${name} deve estar ausente`).toBeUndefined();
  }
  const db = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } });
  const { data: org, error } = await db.from('organizations').select('id,onboarding_state,onboarded_at').eq('slug', 'empresa-p0-de-teste').single();
  expect(error).toBeNull();
  expect(org!.onboarded_at).toBeNull();
  const initial = org!.onboarding_state;
  const snapshots = [];
  for (const width of [1440, 768, 390]) {
    await page.setViewportSize({ width, height: 1000 });
    if (width === 1440) {
      await page.goto('/login');
      await page.locator('#email').fill(process.env.OWNER_EMAIL!);
      await page.locator('#password').fill(process.env.OWNER_PASSWORD!);
      await page.getByRole('button', { name: /^Entrar$/i }).click();
      await page.waitForURL('**/onboarding/welcome');
      await page.locator('#display_name').fill('Empresa P0 de teste');
      await page.locator('input[type="checkbox"]').check();
      await page.getByRole('button', { name: /^Continuar$/i }).click();
      await page.waitForURL('**/onboarding/connect-whatsapp');
    } else await page.goto('/onboarding/connect-whatsapp');
    await expect(page.getByRole('heading', { name: 'Conecte seu WhatsApp' })).toBeVisible();
    await expect(page.getByTestId('forma-qr')).toBeVisible();
    await expect(page.getByTestId('forma-oficial')).toBeVisible();
    await expect(page.getByRole('link', { name: 'Configurar IA (opcional)' })).toBeVisible();
    await expect(page.getByRole('button', { name: 'Ativar para estes números de teste' })).toHaveCount(0);
    const measure = await page.evaluate(() => {
      const root = document.documentElement;
      const boxes = [...document.querySelectorAll('main h2, main h3, main p, main label, main button, main a')].map(el => {
        const r = el.getBoundingClientRect(); const style = getComputedStyle(el);
        return { text: el.textContent?.slice(0, 70), left: r.left, right: r.right, width: r.width, fontSize: style.fontSize, lineHeight: style.lineHeight, display: style.display };
      });
      return { viewport: innerWidth, scrollWidth: root.scrollWidth, boxes };
    });
    snapshots.push(measure);
    await page.screenshot({ path: `.superpowers/evidence/jornada-p0-2026-09-10/conexao-${width}.png`, fullPage: true });
    expect(measure.scrollWidth, `overflow em ${width}px`).toBeLessThanOrEqual(width + 1);
    for (const box of measure.boxes.filter(box => box.width > 0)) {
      expect(box.left, `${box.text}: esquerda`).toBeGreaterThanOrEqual(-1);
      expect(box.right, `${box.text}: direita`).toBeLessThanOrEqual(width + 1);
    }
  }
  writeFileSync('.superpowers/evidence/jornada-p0-2026-09-10/medidas.json', JSON.stringify(snapshots, null, 2));
  await page.getByTestId('forma-oficial').locator('input').click();
  await expect(page.getByText('Este servidor ainda não está pronto para RECEBER por este caminho.')).toBeVisible();
  await page.getByTestId('voltar-para-escolha').click();
  await page.getByTestId('forma-qr').locator('input').click();
  await expect(page.getByText('Não consegui falar com o WhatsApp', { exact: true })).toBeVisible({ timeout: 30_000 });
  await page.screenshot({ path: '.superpowers/evidence/jornada-p0-2026-09-10/conexao-falha-390.png', fullPage: true });
  await page.getByRole('button', { name: 'Explorar o CRM', exact: true }).last().click();
  await page.waitForURL('**/app/inbox', { timeout: 30_000 });
  await expect(page.getByRole('link', { name: 'Retomar configuração' }).first()).toBeVisible();
  await page.screenshot({ path: '.superpowers/evidence/jornada-p0-2026-09-10/inbox-sem-ia-390.png', fullPage: true });
  const { data: after } = await db.from('organizations').select('onboarding_state,onboarded_at').eq('id', org!.id).single();
  expect(after!.onboarding_state.ai).toBeUndefined();
  expect(after!.onboarded_at).toBeNull();
  const { count: agents } = await db.from('ai_agents').select('id', { count: 'exact', head: true }).eq('organization_id', org!.id);
  expect(agents).toBe(0);
  writeFileSync('.superpowers/evidence/jornada-p0-2026-09-10/estado-fresco.json', JSON.stringify({ initial, after, agents, optionalEnvAbsent: true }, null, 2));
});
