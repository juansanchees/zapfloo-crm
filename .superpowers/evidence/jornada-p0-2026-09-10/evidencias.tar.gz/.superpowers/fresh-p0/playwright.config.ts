import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests/e2e', testMatch: ['proof.spec.ts', 'flow.spec.ts'], workers: 1, retries: 0,
  timeout: 120_000,
  use: { baseURL: 'http://localhost:3012', browserName: 'chromium', trace: 'off' },
  reporter: [['list']],
  outputDir: '../evidence/jornada-p0-2026-09-10/browser',
});
