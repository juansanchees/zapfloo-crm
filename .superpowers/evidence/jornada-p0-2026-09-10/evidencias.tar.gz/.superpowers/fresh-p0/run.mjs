import { execFileSync, spawnSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';

const root = process.cwd();
if (!root.endsWith('/.worktrees/jornada-p0')) throw new Error('Checkout inesperado');
if (existsSync('.env') || existsSync('.env.local')) throw new Error('Env externo recusado');
const cli = '/Users/juansanches/.npm/_npx/98af39c2e6cc769d/node_modules/supabase/bin/supabase';
const local = JSON.parse(execFileSync(cli, ['status', '--workdir', '.superpowers/fresh-p0', '--output', 'json'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }));
if (local.API_URL !== 'http://127.0.0.1:55321') throw new Error('Supabase não é o efêmero esperado');
const generated = path.join(root, '.superpowers/fresh-p0/runtime.json');
if (!existsSync(generated)) writeFileSync(generated, JSON.stringify({ secret: randomBytes(32).toString('base64'), password: randomBytes(24).toString('base64') }), { mode: 0o600 });
const runtime = JSON.parse(readFileSync(generated, 'utf8'));
// Ambiente montado do zero: nenhuma chave opcional da instalação/do shell é herdada.
const env = {
  PATH: process.env.PATH, HOME: process.env.HOME, TMPDIR: process.env.TMPDIR,
  NODE_ENV: 'production', COREPACK_ENABLE_DOWNLOAD_PROMPT: '0', NODE_OPTIONS: '--max-old-space-size=4096',
  NEXT_PUBLIC_SUPABASE_URL: local.API_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY: local.ANON_KEY,
  SUPABASE_SERVICE_ROLE_KEY: local.SERVICE_ROLE_KEY, SUPABASE_DB_URL: local.DB_URL,
  NEXT_PUBLIC_APP_URL: 'http://localhost:3012', NEXT_TELEMETRY_DISABLED: '1',
  INTERNAL_SECRET: runtime.secret, CPF_ENCRYPTION_KEY: runtime.secret,
  WAHA_BYO_ENCRYPTION_KEY: runtime.secret, AI_CRED_AES_KEY: runtime.secret,
  // Obrigatórias no boot de produção, endpoints deliberadamente indisponíveis.
  // NÃO representam pareamento, transporte ou Redis funcionando.
  WAHA_API_BASE_URL: 'http://127.0.0.1:5999', WAHA_API_KEY: runtime.secret,
  WAHA_WEBHOOK_BASE_URL: 'http://localhost:3012',
  UPSTASH_REDIS_REST_URL: 'http://127.0.0.1:5998', UPSTASH_REDIS_REST_TOKEN: runtime.secret,
  OWNER_EMAIL: 'dono-p0@example.test', OWNER_PASSWORD: runtime.password, OWNER_ORG_NAME: 'Empresa P0 de teste',
};
const commands = {
  bootstrap: ['exec', 'tsx', 'scripts/bootstrap-owner.ts'],
  build: ['exec', 'next', 'build'],
  server: ['exec', 'next', 'start', '--hostname', '127.0.0.1', '--port', '3012'],
  test: ['exec', 'playwright', 'test', 'proof.spec.ts', '--config', '.superpowers/fresh-p0/playwright.config.ts'],
  flows: ['exec', 'playwright', 'test', 'flow.spec.ts', '--config', '.superpowers/fresh-p0/playwright.config.ts'],
};
const command = commands[process.argv[2]];
if (!command) throw new Error('bootstrap/build/server/test');
const result = spawnSync('corepack', ['pnpm', ...command], { env, stdio: 'inherit' });
if (result.error) throw result.error;
process.exit(result.status ?? 1);
